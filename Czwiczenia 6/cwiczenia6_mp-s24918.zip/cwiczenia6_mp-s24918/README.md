[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/aYlNan9z)
# Ćwiczenia6

Zadanie do rozwiązania znajdują się w klasie `LinqTasks.cs`. Zadania należy rozwiązać za pomocą składni LINQ.

## Testy
Do zadania zostały dodane testy, które wskazują czy poprawnie rozwiązaliśmy dany `TaskX`. 
